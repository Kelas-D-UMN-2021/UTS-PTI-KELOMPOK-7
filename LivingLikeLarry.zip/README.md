# BIKINI BOTTOM'S LIFE SIMULATOR
## Group 7

### Anggota
- Gerald Imanuel Wijaya/[Geri](https://github.com/geraldimanuelstudent) (00000060106)
- Michael Danda Pratama /[Michael] (00000055630)
- Ikbar Muhammad Mumtaz /[Ikbar] (00000061296)
- Steven Arya Setyadhrama Tri Cahya /[Steve] (00000055610)

### Aturan
1. Untuk menyelesaikan game ini, pemain perlu menyelesaikan 8 semester yang disediakan pada game ini.
2. Untuk memulai game pemain dapat memilih avatar yang diinginkan dan memasukkan nama. Kemudian tekan tombol play. 
3. Terdapat 4 tombol dan 4 status bar yang akan manjadi bagian dalam game (main, belajar, makan, tidur).
4. Untuk mengaktifkan status hanya perlu menekan tombol sekali saja dan status akan bertambah. 
5. Setiap status yang diaktifkan akan berpengaruh pada status lainnya misal (aktifkan belajar maka main dan makan akan berkurang).
6. Apabila pemain idle atau tidak melakukan aktifitas apapun maka seluruh status akan berkurang secara dinamis.
7. Apabila pemain ingin keluar dari permainan maka pemain dapat menekan tombol keluar yang terletak pada sebelah kiri atas.
9. Apabila pemain tidak mengaktifkan status belajar selama 24 jam di dalam simulator maka pemain akan di D.O (game over).
10. Jika salah satu dari 3 status bar (makan, main, tidur) habis/kosong maka permainan akan berakhir (game over).

### DISCLAIMER
1. Musik background SEHARUSNYA berjalan secara otomatis.
2. Musik mungkin tidak jalan dikarenakan browser masing-masing user.
3. Terdapat tombol bantuan pada menu utama.
